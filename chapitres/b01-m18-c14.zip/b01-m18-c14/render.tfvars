# Clé API : 
# Account's Settings -> API Keys -> Create API KEY
# Name : Nom
# Récupérer la clé API
# Récupérer le Owner ID avec une API en Shell: 
# APIKEY="rnd_iYSKfiog8Jq3AqGUyonOYYVe0x7v"
# curl --request GET --url https://api.render.com/v1/owners --header "accept: application/json" --header "authorization: Bearer $APIKEY"
# [{"cursor":"WqskZ-cgj41uOHUwdGJjYzczZG10a3Jn","owner":{"email":"sajjad.azizi.31@gmail.com","id":"tea-das3n8u0tbcc73dmtkrg","name":"Sajjad's workspace","type":"team"}}]

api_key     = "rnd_iYSKfiog8Jq3AqGUyonOYYVe0x7v"
owner_id    = "tea-das3n8u0tbcc73dmtkrg"
environment = "development"
